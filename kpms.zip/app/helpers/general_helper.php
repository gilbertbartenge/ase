<?php 

function user_role()
{
	$CI = & get_instance();
	if($CI->session->userdata('user_role')){
		return $CI->session->userdata('user_role');
	}else{
		return '';
	}
}