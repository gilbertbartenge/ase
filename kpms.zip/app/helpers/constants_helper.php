<?php
// Used all over the application
define('APP_VERSION','1.1.0');
define('APP_NAME','POLICE RECORD MANAGEMENT SYSTEM');


//Define Database Tables
define('TABLE_POLICE_CATEGORIES','tblpolicecategories');
define('TABLE_USERS','tblusers');
define('TABLE_POLICE_STATIONS','tblpolicestations');
define('TABLE_COUNTIES','tblcounties');
define('TABLE_POLICE_FORMULATIONS','tblpoliceformulation');
define('TABLE_POLICE_CASES','tblpolicecases');
define('TABLE_CASE_TYPES','tblcasetypes');
define('TABLE_CRIMINALS','tblcriminals');


// Other constants used in the application.
define('ERROR', 'error');
define('SUCCESS', 'success');
define('ACTION_SUCCESFUL', 'Action Succesful.');
define('ACTION_UNSUCCESFUL', 'Action Unsuccesful.');
define('ADMIN', 'admin');
define('POLICE', 'police');
define('CLIENT', 'client');

