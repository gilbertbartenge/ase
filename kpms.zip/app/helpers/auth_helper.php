<?php

Class Auth
{
	 static function is_loggedin()
	{
		$CI = & get_instance();
		if ($CI->session->has_userdata('user_id') != '')
			return TRUE;
		else
			return FALSE;
	}

	static function Role($role_id = 1)
	{
		$roles = [
			0 => 'Guest',
			1 => 'Police',
			2 => 'Admin',
			2 => 'Zeus'
		];
		return $roles[$role_id];
	}


	static function Logout($type = 'user')
	{
		$CI = & get_instance();
		unset($_SESSION['user_id']);
		unset($_SESSION['user_role']);
		unset($_SESSION['previous_url']);
		$CI->session->sess_destroy();
		redirect(site_url('authentication'));
	}

	static function Login($data = array()){
		$CI = & get_instance();
		$query = $CI->db->get_where(TABLE_USERS, $data);
		$row = $query->row();
		if($query->num_rows() > 0){
			$data = ['last_login'=>date('Y-m-d H:i:s')];
			DB::update(TABLE_USERS, ['id'=>$row->id],$data);
			if($row->banned == 1) {
				$CI->session->set_flashdata(ERROR, 'You have been banned. Please contact the admin.');
				return FALSE;
			}
			
			$userdata = [
				'user_id'=>$row->id,
				'user_role'=>$row->role,
				'name'=>$row->first_name.' '.$row->last_name,
				'user_role'=>$row->role,
			];
			$CI->session->set_userdata($userdata);
			return TRUE;
		}else{
			$CI->session->set_flashdata(ERROR, 'Invalid Username or Password');
			return FALSE;
		}
	}

	static function Bounce($uri_string = '')
	{
		$CI = & get_instance();
		$CI->session->set_userdata('previous_url', $uri_string);
		redirect(site_url('authentication/login'));
	}

}