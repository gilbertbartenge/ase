<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class General_model extends CI_Model
{
	function __construct()
	{
		parent::__construct();

	}


	public function get_submissions($where = [], $limit = 0, $offset = 0)
	{
		
		$query = $this->db->join(TABLE_USERS, TABLE_USERS.'.id = '.TABLE_USER_SUBMISSIONS.'.user_id', 'both');

		if(count($where) < 1)
			$query = $this->db->where($where);

		if($limit != 0)
			$query = $this->db->limit($limit, $offset);

		$query = $this->db->get(TABLE_USER_SUBMISSIONS);
		return $query->result();
	}

	public function api_register($data = [])
	{
		$message = 'Nothing took place';

		$user['username']        = (array_key_exists('username', $data)       ? $data['username']  : '');
		$user['email']           = (array_key_exists('email', $data)          ? $data['email']     : '');
		$user['password']        = (array_key_exists('password', $data)       ? $data['password']  : '');

		if(empty($user['username']) || empty($user['email']) || empty($user['password'])) {
			$message = ['status'=>2, 'message'=>'Some fields are empty'];
		}else if(valid_email($user['email']) == FALSE){
			$message = ['status'=>3, 'message'=>'Email is invalid.'];
		} else if(DB::it_exists(TABLE_USERS, 'email', $user['email'])) {
			$message = ['status'=>4, 'message'=>'Email already exits.'];
		}else if(DB::it_exists(TABLE_USERS, 'username', $user['username'])){
			$message = ['status'=>5, 'message'=>'Username already exits.'];
		}else{
			$data  = [
			'username'=>$user['username'],
			'email'=>$user['email'],
			'password'=>hash('sha256', $user['password']),
			'created_at'=>date('Y-m-d H:i:s')
			];

			if(DB::save(TABLE_USERS, $data)) {
				$message = [
					'status'=>1, 
					'message'=>'Data Saved succefully.',
					'username'=>$user['username'],
					'email'=>$user['email'],
					'password'=>'*****',
					];
			} else {
				$message = [
					'status'=>0, 
					'message'=>'Data passed validation. but an unexpected error occured. data not saved.',
					'username'=>$user['username'],
					'email'=>$user['email'],
					'password'=>$user['password'],
					];
			}
		}

		return $message;

	}

	public function api_login($email = '', $password = '')
	{
		$message = 0;
		if(Auth::IsLoggedIn()){
			$message = ['status'=>2, 'message'=>'User already logged in.'];
		}else{
			if(empty($email) || empty($password)){
				$message = ['status'=>3, 'message'=>'Email or Password is empty'];
			}else if(valid_email($email) == FALSE){
				$message = ['status'=>4, 'message'=>'Email is invalid'];
			}else{
				$login = [
				'email'=>$email,
				'password'=> hash('sha256', $password)
				];

				if(Auth::login($login)) {
					$message = [
						'status'=>1, 
						'message'=>'Login Succesful.',
						'username'=>$this->session->userdata('user_username'),
						'email'=>$email,
						'password'=>$login['password']
						];
				} else {
					$message = [
					'status'=>0, 
					'message'=>'Invalid Username or password',
					'email'=>$email,
					'password'=>$password
					];
				}
			}
		}
		return $message;
	}

	function get_api_ads()
	{
		$today = date('Y-m-d');
		$query = $this->db->where('status', 'active');
		$query = $this->db->where('startdate <=', $today);
		$query = $this->db->where('enddate >=', $today);
		$query = $this->db->get_where(TABLE_ADS);
		return $query->result();
	}
}