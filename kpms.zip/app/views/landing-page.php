<!DOCTYPE html>
<html lang="en">
<head>
    <!--SEO Meta Tags-->
    <meta charset="utf-8" />
    <!-- SITE TITLE -->
    <title><?=APP_NAME ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta content="Responsive Bootstrap Multi-Purpose Landing Page Template" name="description" />
    <meta name="keywords" content="Landing, Bootstrap, Landing page, Template, Registration, Landing">
    <meta content="" name="author" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <link rel="shortcut icon" href="<?=base_url() ?>assets/images/favicon.png">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Noto+Sans:400,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Hind:500,600,700" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link href="<?=base_url() ?>assets/landing-page/css/bootstrap.min.css" rel="stylesheet">

    <!-- Icon CSS -->
    <link href="<?=base_url() ?>assets/landing-page/css/themify-icons.css" rel="stylesheet">

    <!-- Owl Carousel CSS -->
    <link href="<?=base_url() ?>assets/landing-page/css/owl.carousel.css" rel="stylesheet">
    <link href="<?=base_url() ?>assets/landing-page/css/owl.theme.default.min.css" rel="stylesheet">

    <!-- Magnific-popup -->
    <link rel="stylesheet" href="<?=base_url() ?>assets/landing-page/css/magnific-popup.css">

    <!-- Custom styles for this template -->
    <link href="<?=base_url() ?>assets/landing-page/css/style.css" rel="stylesheet">


    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
        <!--[if lt IE 9]>
          <script src="<?=base_url() ?>assets/landing-page/js/html5shiv.js"></script>
          <script src="<?=base_url() ?>assets/landing-page/js/respond.min.js"></script>
          <![endif]-->

      </head>


      <body  data-spy="scroll" data-target="#data-scroll">

        <!-- Loader -->
        <div id="preloader"><div id="status"><div class="spinner">Loading...</div></div></div>


        <!-- Navbar -->
        <div class="navbar navbar-custom sticky" role="navigation">
            <div class="container">
                <!-- Navbar-header -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <i class="ti-menu"></i>
                    </button>
                    <!-- LOGO -->
                    <a class="navbar-brand logo" href="<?=site_url() ?>">
                        <small class="glyphicon-user glyphicon"></small> PRMS</span>
                    </a>
                </div>
                <!-- end navbar-header -->

                <!-- menu -->
                <div class="navbar-collapse collapse" id="data-scroll">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="active">
                            <a href="<?=site_url() ?>">Home</a>
                        </li>
                        <li>
                            <a href="<?=site_url('authentication') ?>">Login</a>
                           
                        </li>

                    </ul>
                </div>
                <!--/Menu -->
            </div>
            <!-- end container -->
        </div>



        <!-- HOME -->
        <section class="home bg-home" id="home">

            <div class="bg-overlay"></div>

            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="home-fullscreen" id="home-fullscreen">
                            <div class="full-screen">
                                <div class="home-wrapper home-wrapper-alt">
                                    <div class="row">
                                        <div class="col-md-8 col-md-offset-2 text-center">
                                        <h1>Kenyan Police Record Management System</h1>
                                            <h4>A web based record management system for the police department. By PhantoEvans Technologies</h4>
                                            <a href="<?=site_url('authentication') ?>" class="btn btn-custom">Login</a>
                                            <a href="http://www.kampozone.com" class="video-btn btn popup-video" id="popup-video"><i class="glyphicon glyphicon-play"></i>Learn More</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> <!-- end col -->
                </div> <!-- end row -->
            </div>
            <!-- end container -->
        </section>
        <!-- END HOME -->

        <!-- COPYRIGHT -->
        <div class="footer-alt bg-dark">
            <p class="copy-rights"><?=date('Y') ?> © PhantoEvans Technologies all rights reserved</p>
        </div>


        <!-- js placed at the end of the document so the pages load faster -->
        <script type="text/javascript" src="<?=base_url() ?>assets/landing-page/js/jquery-2.1.4.min.js"></script>
        <script type="text/javascript" src="<?=base_url() ?>assets/landing-page/js/bootstrap.min.js"></script>

        <!-- Sticky Header -->
        <script type="text/javascript" src="<?=base_url() ?>assets/landing-page/js/jquery.sticky.js"></script>

        <!-- Jquery easing -->                                                      
        <script type="text/javascript" src="<?=base_url() ?>assets/landing-page/js/jquery.easing.1.3.min.js"></script>

        <!-- Owl Carousel -->                                                      
        <script type="text/javascript" src="<?=base_url() ?>assets/landing-page/js/owl.carousel.min.js"></script>

        <!-- Magnific Popup -->
        <script type="text/javascript" src="<?=base_url() ?>assets/landing-page/js/jquery.magnific-popup.min.js"></script>

        <!-- parsley - form validation -->
        <script type="text/javascript" src="<?=base_url() ?>assets/landing-page/js/parsley.min.js"></script>

        <!-- Custom js -->
        <script type="text/javascript" src="<?=base_url() ?>assets/landing-page/js/app.js"></script>
    </body>
    </html>