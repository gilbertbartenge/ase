<?php $this->load->view('includes/head') ?>

<body>
	<?php $this->load->view('includes/nav') ?>
</body>

<div class="wrapper">
	<?php isset($page) ? $this->load->view($page) : 'dashboard/index' ?>
</div>
<?php $this->load->view('includes/scripts') ?>
<?php isset($page_js) ? $this->load->view($page_js) : ''  ?>
</body>
</html>
