<?php $this->load->view('includes/tables-head') ?>

<body>
	<?php $this->load->view('includes/nav') ?>
</body>

<div class="wrapper">
	<?php isset($page) ? $this->load->view($page) : 'dashboard/index' ?>
</div>
<?php $this->load->view('includes/tables-scripts') ?>
<?php isset($page_js) ? $this->load->view($page_js) : ''  ?>
</body>
</html>
