<!-- jQuery  -->
    <script src="<?=base_url() ?>assets/js/jquery.min.js"></script>
    <script src="<?=base_url() ?>assets/js/bootstrap.min.js"></script>
    <script src="<?=base_url() ?>assets/js/detect.js"></script>
    <script src="<?=base_url() ?>assets/js/fastclick.js"></script>
    <script src="<?=base_url() ?>assets/js/jquery.blockUI.js"></script>
    <script src="<?=base_url() ?>assets/js/waves.js"></script>
    <script src="<?=base_url() ?>assets/js/jquery.slimscroll.js"></script>
    <script src="<?=base_url() ?>assets/js/jquery.scrollTo.min.js"></script>
    <script src="<?=base_url() ?>assets/plugins/switchery/switchery.min.js"></script>

    <script src="<?=base_url() ?>assets/plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="<?=base_url() ?>assets/plugins/datatables/dataTables.bootstrap.js"></script>

    <script src="<?=base_url() ?>assets/plugins/datatables/dataTables.buttons.min.js"></script>
    <script src="<?=base_url() ?>assets/plugins/datatables/buttons.bootstrap.min.js"></script>
    <script src="<?=base_url() ?>assets/plugins/datatables/pdfmake.min.js"></script>
    <script src="<?=base_url() ?>assets/plugins/datatables/vfs_fonts.js"></script>
    <script src="<?=base_url() ?>assets/plugins/datatables/buttons.html5.min.js"></script>
    <script src="<?=base_url() ?>assets/plugins/datatables/buttons.print.min.js"></script>
    <script src="<?=base_url() ?>assets/plugins/datatables/dataTables.fixedHeader.min.js"></script>
    <script src="<?=base_url() ?>assets/plugins/datatables/dataTables.keyTable.min.js"></script>
    <script src="<?=base_url() ?>assets/plugins/datatables/dataTables.responsive.min.js"></script>
    <script src="<?=base_url() ?>assets/plugins/datatables/responsive.bootstrap.min.js"></script>
    <script src="<?=base_url() ?>assets/plugins/datatables/dataTables.scroller.min.js"></script>
    <script src="<?=base_url() ?>assets/plugins/datatables/dataTables.colVis.js"></script>
    <script src="<?=base_url() ?>assets/plugins/datatables/dataTables.fixedColumns.min.js"></script>

    <script type="text/javascript" src="<?=base_url() ?>assets/bower_components/moment/min/moment.min.js"></script>
    <script type="text/javascript" src="<?=base_url() ?>assets/bower_components/eonasdan-bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js"></script>

    <!-- init -->
    <script src="<?=base_url() ?>assets/pages/jquery.datatables.init.js"></script>

    <!-- App js -->
    <script src="<?=base_url() ?>assets/js/jquery.core.js"></script>
    <script src="<?=base_url() ?>assets/js/jquery.app.js"></script>

    <script type="text/javascript">
        TableManageButtons.init();
    </script>