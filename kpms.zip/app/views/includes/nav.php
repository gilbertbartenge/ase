 <!-- Navigation Bar-->
        <header id="topnav">
            <div class="topbar-main">
                <div class="container">

                    <!-- Logo container-->
                    <div class="logo">
                        <!-- Text Logo -->
                        <!--<a href="index.html" class="logo">-->
                            <!--Zircos-->
                        <!--</a>-->
                        <!-- Image Logo -->
                        <a href="dashboard.php" class="logo">
                            <img src="<?=base_url() ?>assets/images/logo.png" alt="" height="30">
                        </a>

                    </div>
                    <!-- End Logo container-->


                    <div class="menu-extras">

                        <ul class="nav navbar-nav navbar-right pull-right">
                            <li class="navbar-c-items">
                                <form role="search" class="navbar-left app-search pull-left hidden-xs">
                                     <input type="text" placeholder="Search..." class="form-control">
                                     <a href="#"><i class="fa fa-search"></i></a>
                                </form>
                            </li>



                            <li class="dropdown navbar-c-items">
                                <a href="#" class="dropdown-toggle waves-effect waves-light profile" data-toggle="dropdown" aria-expanded="true"><img src="<?=base_url() ?>assets/images/users/male.png" alt="user-img" class="img-circle"> </a>
                                <ul class="dropdown-menu dropdown-menu-right arrow-dropdown-menu arrow-menu-right user-list notify-list">
                                    <li class="text-center">
                                        <h5>Hi, <?=ucwords($this->session->userdata('name')) ?></h5>
                                    </li>
                                    <li><a href="<?=site_url('authentication/logout') ?>"><i class="ti-power-off m-r-5"></i> Logout</a></li>
                                </ul>

                            </li>
                        </ul>
                        <div class="menu-item">
                            <!-- Mobile menu toggle-->
                            <a class="navbar-toggle">
                                <div class="lines">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </div>
                            </a>
                            <!-- End mobile menu toggle-->
                        </div>
                    </div>
                    <!-- end menu-extras -->

                </div> <!-- end container -->
            </div>
            <!-- end topbar-main -->

            <div class="navbar-custom">
                <div class="container">
                    <div id="navigation">
                        <!-- Navigation Menu-->
                       <ul class="navigation-menu">

                            <li class="">
                                <a href="<?=site_url('home') ?>"><i class="mdi mdi-view-dashboard"></i>Dashboard</a>
                            </li>
                            <?php if(user_role() == ADMIN || user_role() == POLICE): ?>
                            <li class="has-submenu">
                                <a href="#"><i class="mdi mdi-account-network"></i>Police Categories</a>
                                <ul class="submenu">
                                    <li><a href="<?=site_url('categories') ?>">View All</a></li>
                                    <li><a href="<?=site_url('categories/formulations') ?>">Police Formulations</a></li>
                                </ul>
                            </li>


                            <li class="has-submenu">
                                <a href="#"><i class="mdi mdi-castle"></i>Police Stations</a>
                                <ul class="submenu">
                                    <li><a href="<?=site_url('stations') ?>">View All</a></li>
                                </ul>
                            </li>
                             <?php endif; ?>
                            <li class="has-submenu">
                                <a href="#"><i class="mdi mdi-clipboard-alert"></i>Cases</a>
                                <ul class="submenu">
                                    <li><a href="<?=site_url('cases') ?>">View All</a></li>
                                    <?php if(user_role() == ADMIN): ?>
                                    <li><a href="<?=site_url('cases/case_types') ?>">Case Types</a></li>
                                <?php endif; ?>
                                </ul>
                            </li>

                            <li class="has-submenu">
                                <a href="<?=site_url('criminals') ?>"><i class="mdi mdi-alert"></i>Criminals</a>
                            </li>
                            <?php if(user_role() == ADMIN): ?>
                            <li class="has-submenu">
                                <a href="<?=site_url('users') ?>"><i class="mdi mdi mdi-account"></i>System Users</a>
                            </li>
                        <?php endif; ?>
                        </ul>
                        <!-- End navigation menu -->
                    </div> <!-- end #navigation -->
                </div> <!-- end container -->
            </div> <!-- end navbar-custom -->
        </header>
        <!-- End Navigation Bar-->