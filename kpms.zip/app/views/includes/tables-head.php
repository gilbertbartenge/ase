
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="<?=APP_NAME ?>">
        <meta name="author" content="Olaiya Segun paul. (Nigerian) +2348175020329 Email: vadeshayo@gmail.com Twitter: massivebrains00">

      <link rel="shortcut icon" href="<?=base_url() ?>assets/images/favicon.png">

        <title><?=isset($title) ? $title : APP_NAME ?></title>

        <!-- DataTables -->
        <link href="<?=base_url() ?>assets/plugins/datatables/jquery.dataTables.min.css" rel="stylesheet" type="text/css"/>
        <link href="<?=base_url() ?>assets/plugins/datatables/buttons.bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="<?=base_url() ?>assets/plugins/datatables/fixedHeader.bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="<?=base_url() ?>assets/plugins/datatables/responsive.bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="<?=base_url() ?>assets/plugins/datatables/scroller.bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="<?=base_url() ?>assets/plugins/datatables/dataTables.colVis.css" rel="stylesheet" type="text/css"/>
        <link href="<?=base_url() ?>assets/plugins/datatables/dataTables.bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="<?=base_url() ?>assets/plugins/datatables/fixedColumns.dataTables.min.css" rel="stylesheet" type="text/css"/>

        <!-- App css -->
        <link href="<?=base_url() ?>assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="<?=base_url() ?>assets/css/core.css" rel="stylesheet" type="text/css" />
        <link href="<?=base_url() ?>assets/css/components.css" rel="stylesheet" type="text/css" />
        <link href="<?=base_url() ?>assets/css/icons.css" rel="stylesheet" type="text/css" />
        <link href="<?=base_url() ?>assets/css/pages.css" rel="stylesheet" type="text/css" />
        <link href="<?=base_url() ?>assets/css/menu.css" rel="stylesheet" type="text/css" />
        <link href="<?=base_url() ?>assets/css/responsive.css" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="<?=base_url() ?>assets/plugins/switchery/switchery.min.css">
        <link rel="stylesheet" href="<?=base_url() ?>assets/bower_components/eonasdan-bootstrap-datetimepicker/build/css/bootstrap-datetimepicker.min.css" />

        <!-- HTML5 Shiv and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
        <![endif]-->

        <script src="<?=base_url() ?>assets/js/modernizr.min.js"></script>
    </head>