<!-- jQuery  -->
<script src="<?=base_url() ?>assets/js/jquery.min.js"></script>
<script src="<?=base_url() ?>assets/js/bootstrap.min.js"></script>
<script src="<?=base_url() ?>assets/js/detect.js"></script>
<script src="<?=base_url() ?>assets/js/fastclick.js"></script>
<script src="<?=base_url() ?>assets/js/jquery.blockUI.js"></script>
<script src="<?=base_url() ?>assets/js/waves.js"></script>
<script src="<?=base_url() ?>assets/js/jquery.slimscroll.js"></script>
<script src="<?=base_url() ?>assets/js/jquery.scrollTo.min.js"></script>
<script src="<?=base_url() ?>assets/plugins/switchery/switchery.min.js"></script>

<!-- App js -->
<script src="<?=base_url() ?>assets/js/jquery.core.js"></script>
<script src="<?=base_url() ?>assets/js/jquery.app.js"></script>


