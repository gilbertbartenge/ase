<!-- jQuery  -->
<script src="<?=base_url() ?>assets/js/jquery.min.js"></script>
<script src="<?=base_url() ?>assets/js/bootstrap.min.js"></script>
<script src="<?=base_url() ?>assets/js/detect.js"></script>
<script src="<?=base_url() ?>assets/js/fastclick.js"></script>
<script src="<?=base_url() ?>assets/js/jquery.blockUI.js"></script>
<script src="<?=base_url() ?>assets/js/waves.js"></script>
<script src="<?=base_url() ?>assets/js/jquery.slimscroll.js"></script>
<script src="<?=base_url() ?>assets/js/jquery.scrollTo.min.js"></script>
<script src="<?=base_url() ?>assets/plugins/switchery/switchery.min.js"></script>

<!-- Counter js  -->
<script src="<?=base_url() ?>assets/plugins/waypoints/jquery.waypoints.min.js"></script>
<script src="<?=base_url() ?>assets/plugins/counterup/jquery.counterup.min.js"></script>

<!-- Flot chart js -->
<script src="<?=base_url() ?>assets/plugins/flot-chart/jquery.flot.min.js"></script>
<script src="<?=base_url() ?>assets/plugins/flot-chart/jquery.flot.time.js"></script>
<script src="<?=base_url() ?>assets/plugins/flot-chart/jquery.flot.tooltip.min.js"></script>
<script src="<?=base_url() ?>assets/plugins/flot-chart/jquery.flot.resize.js"></script>
<script src="<?=base_url() ?>assets/plugins/flot-chart/jquery.flot.pie.js"></script>
<script src="<?=base_url() ?>assets/plugins/flot-chart/jquery.flot.selection.js"></script>
<script src="<?=base_url() ?>assets/plugins/flot-chart/jquery.flot.crosshair.js"></script>

<script src="assets/plugins/moment/moment.js"></script>


<!-- Dashboard init -->
<script src="<?=base_url() ?>assets/pages/jquery.dashboard_2.js"></script>

<!-- App js -->
<script src="<?=base_url() ?>assets/js/jquery.core.js"></script>
<script src="<?=base_url() ?>assets/js/jquery.app.js"></script>


