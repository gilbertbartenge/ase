<script>
	function edit(id){
		var name = $('#name-'+id).html();
		var county_id = $('#county_id-'+id).html();
		var address = $('#address-'+id).html();
		var phone = $('#phone-'+id).html();
		var police_category_id = $('#police_category_id-'+id).html();

		$('#station_id').val(id);
		$('#name').val(name);
		$('#county_id').val(county_id);
		$('#police_category_id').val(police_category_id);
		$('#address').val(address);
		$('#phone').val(phone);
		$('#modal').modal();
	}
</script>