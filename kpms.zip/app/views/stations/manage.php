<div class="container">

    <!-- Page-Title -->
    <div class="row">
        <div class="col-sm-12">
            <div class="page-title-box">
                <div class="btn-group pull-right">
                    <ol class="breadcrumb hide-phone p-0 m-0">
                        <li>
                            <a href="#"><?=APP_NAME ?></a>
                        </li>
                        <li class="active">
                            Police Stations
                        </li>
                    </ol>
                </div>
                <h4 class="page-title">Police Stations</h4>
            </div>
        </div>
    </div>
    <!-- end page title end breadcrumb -->

    <?php $this->load->view('includes/alert') ?>
    <div class="row">
        <div class="col-sm-12">
            <div class="card-box table-responsive">
                <p class="text-muted font-13 m-b-30">
                    <?php if(user_role() == ADMIN): ?>
                    <a data-toggle="modal" href='#modal' class="btn btn-inverse">Add Station</a>
                <?php endif; ?>
                </p>

                <table id="datatable-buttons" class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>County</th>
                            <th>Address</th>
                            <th>Phone(s)</th>
                            <th>Category</th>
                            <th>Depts.</th>
                            <th>Date Created</th>
                            <?php if(user_role() == ADMIN): ?>
                            <th>Actions</th>
                        <?php endif; ?>
                        </tr>
                    </thead>


                    <tbody>
                        <?php if(isset($stations)): ?>
                            <?php foreach($stations as $row): ?>
                                <tr>
                                    <td id="name-<?=$row->id?>"><?=ucfirst($row->name) ?></td>
                                    <td>
                                        <?=DB::get_cell(TABLE_COUNTIES, ['id'=>$row->county_id], 'name') ?>
                                        <span style='display:none' id="county_id-<?=$row->id?>"><?=$row->county_id ?></span>
                                    </td>
                                    <td id="address-<?=$row->id?>"><?=ucfirst($row->address) ?></td>
                                    <td id="phone-<?=$row->id?>"><?=ucfirst($row->phone) ?></td>
                                    <td>
                                        <span style='display:none' id="police_category_id-<?=$row->id?>"><?=$row->police_category_id ?></span>
                                        <?=DB::get_cell(TABLE_POLICE_CATEGORIES, ['id'=>$row->police_category_id], 'name') ?></td>
                                    <td>979</td>
                                    <td><?=$row->created_at ?></td>
                                    <?php if(user_role() == ADMIN): ?>
                                    <td>
                                        <div class="btn-group">
                                            <button type="button" class="btn btn-default dropdown-toggle waves-effect" data-toggle="dropdown" aria-expanded="true"> Dropdown <span class="caret"></span> </button>
                                            <ul class="dropdown-menu">
                                                <li><a href="javascript:void(0);" onclick="edit('<?=$row->id ?>')">Edit</a></li>
                                                <li><a href="<?=site_url('stations/delete/'.$row->id) ?>" onclick="return confirm('Are you sure?')">Delete</a></li>
                                            </ul>
                                        </div>
                                    </td>
                                <?php endif; ?>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="modal fade" id="modal">
        <div class="modal-dialog">
            <?=form_open('stations/manage') ?>
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Police Station</h4>
                </div>

                <div class="modal-body">
                    <div class="form-group">
                        <label for="">Police Category</label>
                        <select name="police_category_id" id="police_category_id" class="form-control" required>
                            <option value="">--select--</option>
                            <?php foreach(DB::get(TABLE_POLICE_CATEGORIES) as $row): ?>
                                <option value="<?=$row->id ?>"><?=$row->name ?></option>}
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                       <label for="">Police Station Name</label>
                       <input type="text" name="name" class="form-control" required id="name">
                   </div> 
                   <div class="form-group">
                        <label for="">County</label>
                        <select name="county_id" id="county_id" class="form-control" required>
                            <option value="">--select--</option>
                            <?php foreach(DB::get(TABLE_COUNTIES) as $row): ?>
                                <option value="<?=$row->id ?>"><?=$row->name ?></option>}
                            <?php endforeach; ?>
                        </select>
                    </div>
                   <div class="form-group">
                       <label for="">Phone <small class="text-info">(Input all phone numbers separated by comma)</small></label>
                       <input type="text" name="phone" class="form-control" id="phone">
                   </div> 
                   <div class="form-group">
                       <label for="">Address</label>
                       <textarea name="address" id="address" class="form-control" rows="3" required></textarea>
                   </div> 
               </div>
               <input type="hidden" name="id" id="station_id">
               <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save</button>
            </div>
        </div>
        <?=form_close() ?>
    </div>
</div>

<?php $this->load->view('includes/footer') ?>

    </div> <!-- end container -->