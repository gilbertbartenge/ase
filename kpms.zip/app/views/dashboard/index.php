<link rel="stylesheet" type="text/css" href="<?=base_url('assets/plugins/fancybox/source/jquery.fancybox.css') ?>">

<div class="container">

    <!-- Page-Title -->
    <div class="row">
        <div class="col-sm-12">
            <div class="page-title-box">
                <div class="btn-group pull-right">
                    <ol class="breadcrumb hide-phone p-0 m-0">
                        <li>
                            <a href="#"><?=APP_NAME ?></a>
                        </li>
                        <li class="active">
                            <a href="#">Dashboard</a>
                        </li>
                    </ol>
                </div>
                <h4 class="page-title">Dashboard</h4>
            </div>
        </div>
    </div>
    <!-- end page title end breadcrumb -->

    <?php if(user_role() == ADMIN): ?>
    <div class="row">

        <div class="col-lg-3 col-md-6">
            <div class="card-box widget-box-two widget-two-primary">
                <i class="mdi mdi mdi-clipboard-text widget-two-icon"></i>
                <div class="wigdet-two-content">
                    <p class="m-0 text-uppercase font-600 font-secondary text-overflow" title="Statistics">
                        Total Open Cases
                    </p>
                    <h2><span data-plugin="counterup"><?=number_format(DB::num_rows(TABLE_POLICE_CASES, ['status'=>'open'])) ?></span></h2>
                    <p class="text-muted m-0"><b><?=number_format(DB::num_rows(TABLE_POLICE_CASES, ['status'=>'closed'])) ?></b> Closed</p>
                </div>
            </div>
        </div><!-- end col -->

        <div class="col-lg-3 col-md-6"> 
            <div class="card-box widget-box-two widget-two-warning">
                <i class="mdi mdi-clipboard-alert widget-two-icon"></i>
                <div class="wigdet-two-content">
                    <p class="m-0 text-uppercase font-600 font-secondary text-overflow" title="User This Month">
                        Total Closed Cases
                    </p>
                    <h2><span data-plugin="counterup"><?=number_format(DB::num_rows(TABLE_POLICE_CASES, ['status'=>'closed'])) ?> </span> </h2>
                    <p class="text-muted m-0"><b><?=number_format(DB::num_rows(TABLE_POLICE_CASES, ['status'=>'open'])) ?></b> Open</p>
                </div>
            </div>
        </div><!-- end col -->

        <div class="col-lg-3 col-md-6">
            <div class="card-box widget-box-two widget-two-danger">
                <i class="mdi mdi mdi-alert widget-two-icon"></i>
                <div class="wigdet-two-content">
                    <p class="m-0 text-uppercase font-600 font-secondary text-overflow" title="Statistics">
                        Total Criminals
                    </p>
                    <h2><span data-plugin="counterup"><?=number_format(DB::num_rows(TABLE_CRIMINALS)) ?></span> </h2>
                    <p class="text-muted m-0"><b><?=number_format(DB::num_rows(TABLE_CRIMINALS, ['status'=>'wanted'])) ?> Wanted.</b> <?=number_format(DB::num_rows(TABLE_CRIMINALS, ['status'=>'most_wanted'])) ?> most wanted.</p>
                </div>
            </div>
        </div><!-- end col -->

        <div class="col-lg-3 col-md-6">
            <div class="card-box widget-box-two widget-two-success">
                <i class="mdi mdi-account-multiple widget-two-icon"></i>
                <div class="wigdet-two-content">
                    <p class="m-0 text-uppercase font-600 font-secondary text-overflow" title="User Today">
                        System Users
                    </p>
                    <h2><span data-plugin="counterup"><?=number_format(DB::num_rows(TABLE_USERS)) ?></span> </h2>
                    <p class="text-muted m-0"><b>System Date:</b> <?=date('Y-m-d') ?></p>
                </div>
            </div>
        </div><!-- end col -->

    </div>
    <!-- end row -->
<?php endif; ?>


    <div class="row">
        <div class="col-md-4">
            <div class="card-box">
                <h4 class="header-title m-t-0 m-b-30">Most Wanted Criminals</h4>

                <div class="inbox-widget slimscroll-alt" style="min-height: 302px;">
                    <?php $most_wanted = DB::get(TABLE_CRIMINALS, 'id', 'DESC', 10, 0, ['status'=>'most_wanted']) ?>
                    <?php foreach($most_wanted as $row): ?>
                        <a href="#">
                            <div class="inbox-item">
                                <?php 
                                if(empty($row->image)){
                                    if($row->sex == 'male'){
                                        $image = 'male.png';
                                    }else{
                                        $image = 'female.png';
                                    }
                                }else{
                                    $image = $row->image;
                                }
                                ?>
                                <div class="inbox-item-img">
                                    <a class="fancybox" rel="group" href="<?=base_url('assets/criminals/'.$image) ?>">
                                      <img src="<?=base_url('assets/criminals/'.$image) ?>" alt="<?=$row->first_name ?>" class="img img-responsive">
                                  </a>
                              </div>
                              <p class="inbox-item-author"><?=$row->first_name. ' '.$row->last_name ?></p>
                              <p class="inbox-item-text"><?=$row->created_at ?></p>
                              <p class="inbox-item-date"><?=$row->sex ?></p>
                          </div>
                      </a>
                  <?php endforeach; ?>
              </div>

          </div> <!-- end card -->
      </div>
      <!-- end col -->

      <div class="col-md-8">
        <div class="card-box">
            <h4 class="header-title m-t-0 m-b-30">Recent Cases Submitted</h4>

            <div class="table-responsive">
                <table class="table table table-hover m-0">
                    <thead>
                        <tr>
                            <th>Case Number Type</th>
                            <th>Date of Report</th>
                            <th>Suspect Name</th>
                            <th>Case Category</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $recent_cases = DB::get(TABLE_POLICE_CASES, 'id', 'DESC', 10, 0); ?>
                        <?php foreach($recent_cases as $row): ?>
                            <tr>
                                <th><strong><a href="#" title="" ><?=$row->case_number ?></a></strong></th>
                                <td><?=$row->date_of_report ?></td>
                                <td><?=$row->suspect_first_name.' '.$row->suspect_last_name ?></td>
                                <td><?=DB::get_cell(TABLE_CASE_TYPES, ['id'=>$row->case_type_id], 'case_type') ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

            </div> <!-- table-responsive -->
        </div> <!-- end card -->
    </div>
    <!-- end col -->

</div>
<!-- end row -->



<?php $this->load->view('includes/footer') ?>

</div>