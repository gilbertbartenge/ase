<script src="<?=base_url('assets/plugins/fancybox/lib/jquery.mousewheel-3.0.6.pack.js') ?>"></script>
<script src="<?=base_url('assets/plugins/fancybox/source/jquery.fancybox.js') ?>"></script>
<script>
	function edit(id){
		var first_name = $('#first_name-'+id).html();
		var last_name = $('#last_name-'+id).html();
		var sex = $('#sex-'+id).html();
		var status = $('#status-'+id).html();

		$('#criminal_id').val(id);
		$('#first_name').val(first_name);
		$('#sex').val(sex);
		$('#status').val(status);
		$('#last_name').val(last_name);
		$('#modal').modal();
	}

	function upload(id)
	{
		$('#criminal_id_upload').val(id);
		$('#upload').modal();
	}
	$(document).ready(function(){
		$('.fancybox').fancybox();
	})
</script>
