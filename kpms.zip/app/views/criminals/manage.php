<div class="container">
<link rel="stylesheet" type="text/css" href="<?=base_url('assets/plugins/fancybox/source/jquery.fancybox.css') ?>">
  <!-- Page-Title -->
  <div class="row">
    <div class="col-sm-12">
      <div class="page-title-box">
        <div class="btn-group pull-right">
          <ol class="breadcrumb hide-phone p-0 m-0">
            <li>
              <a href="#"><?=APP_NAME ?></a>
            </li>
            <li class="active">
              Criminals
            </li>
          </ol>
        </div>
        <h4 class="page-title">Criminals</h4>
      </div>
    </div>
  </div>
  <!-- end page title end breadcrumb -->

  <?php $this->load->view('includes/alert') ?>
  <div class="row">
    <div class="col-sm-12">
      <div class="card-box table-responsive">
        <p class="text-muted font-13 m-b-30">
          <a data-toggle="modal" href='#modal' class="btn btn-inverse">Add Criminal</a>
        </p>

        <table id="datatable-buttons" class="table table-striped table-bordered">
          <thead>
            <tr>
              <th>Image</th>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Sex</th>
              <th>Status</th>
              <th>Date Created</th>
              <?php if(user_role() == ADMIN): ?>
              <th>Actions</th>
            <?php endif; ?>
            </tr>
          </thead>


          <tbody>
            <?php if(isset($criminals)): ?>
              <?php $count = 1; ?>
              <?php foreach($criminals as $row): ?>
                <tr>
                  <td>
                    <?php 
                    if(empty($row->image)){
                      if($row->sex == 'male'){
                        $image = 'male.png';
                      }else{
                        $image = 'female.png';
                      }
                    }else{
                      $image = $row->image;
                    }
                    ?>
                    <a class="fancybox" rel="group" href="<?=base_url('assets/criminals/'.$image) ?>">
                      <img src="<?=base_url('assets/criminals/'.$image) ?>" alt="<?=$row->first_name ?>" class="img img-responsive" style="width:50px; height:50px;">
                    </a>
                  </td>
                  <td id="first_name-<?=$row->id ?>"><?=ucfirst($row->first_name) ?></td>
                  <td id="last_name-<?=$row->id ?>"><?=ucfirst($row->last_name) ?></td>
                  <td id="sex-<?=$row->id ?>"><?=$row->sex ?></td>
                  <td id="status-<?=$row->id ?>"><?=$row->status ?></td>
                  <td><?=$row->created_at ?></span></td>
                  <?php if(user_role() == ADMIN): ?>
                  <td>
                    <div class="btn-group">
                      <button type="button" class="btn btn-default dropdown-toggle waves-effect" data-toggle="dropdown" aria-expanded="true"> Dropdown <span class="caret"></span> </button>
                      <ul class="dropdown-menu">
                        <li><a href="javascript:void(0);" onclick="edit('<?=$row->id ?>')">View</a></li>
                        <li><a href="javascript:void(0);" onclick="upload('<?=$row->id ?>')">Upload Picture</a></li>
                        <li><a href="<?=site_url('criminals/delete/'.$row->id)?>" onclick="return confirm('Are you sure?')">Delete</a></li>
                      </ul>
                    </div>
                  </td>
                <?php endif; ?>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <div class="modal fade" id="modal">
    <div class="modal-dialog">
      <?=form_open('criminals/manage') ?>
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
          <h4 class="modal-title">Criminal</h4>
        </div>
        <div class="modal-body">
         <div class="form-group">
           <label for="">Criminal First Name</label>
           <input type="text" name="first_name" class="form-control" id="first_name" required>
         </div> 

         <div class="form-group">
           <label for="">Criminal Last Name</label>
           <input type="text" name="last_name" class="form-control" id="last_name" required>
         </div>

         <div class="form-group">
           <label for="">Sex</label>
           <select name="sex"  class="form-control" required>
             <option value="male">Male</option>
             <option value="female">Female</option>
           </select>
         </div>

         <div class="form-group">
           <label for="">Status</label>
           <select name="status"  class="form-control" required>
             <option value="regular">Mark as Regular</option>
             <option value="wanted">Mark as Wanted</option>
             <option value="most_wanted">Mark as Most Wanted</option>
           </select>
         </div> 

         <input type="hidden" name="id" id="criminal_id">
       </div>
       <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save</button>
      </div>
    </div>
    <?=form_close() ?>
  </div>
</div>

<div class="modal fade" id="upload">
  <div class="modal-dialog">
    <?=form_open_multipart('criminals/upload_image') ?>
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title">Upload Image</h4>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label for="">Select Image to uplaod</label>
          <input type="file" name="image"  class="form-control" value="" required>
        </div>
        <input type="hidden" name="criminal_id" value="" id="criminal_id_upload">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save changes</button>
      </div>
    </div>
    <?=form_close() ?>
  </div>
</div>

<?php $this->load->view('includes/footer') ?>

    </div> <!-- end container -->