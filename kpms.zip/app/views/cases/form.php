<link rel="stylesheet" type="text/css" href="<?=base_url('assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css') ?>">
<div class="container">
    <!-- Page-Title -->
    <?php $this->load->view('includes/alert') ?>
    <div class="row">
        <div class="col-sm-12">
            <div class="page-title-box">
                <div class="btn-group pull-right">
                    <ol class="breadcrumb hide-phone p-0 m-0">
                        <li>
                            <a href="#"><?=APP_NAME ?></a>
                        </li>
                        <li class="active">
                            Case
                        </li>
                    </ol>
                </div>
                <h4 class="page-title">Case</h4>
            </div>
        </div>
    </div>
    <!-- end page title end breadcrumb -->

    <div class="row">
        <div class="col-sm-12">
            <div class="card-box table-responsive">
                <h4 class="m-t-0 header-title"><b>Case Form</b></h4>

                <?=form_open('cases/manage') ?>
                <?php $suspect_first_name = isset($case) ? $case->suspect_first_name : set_value('suspect_first_name') ?>
                <div class="form-group">
                    <label for="">Suspect First Name</label>
                    <input type="text" name="suspect_first_name" id="suspect_first_name" class="form-control" value="<?=$suspect_first_name ?>" required>
                </div> 
                <?php $suspect_last_name = isset($case) ? $case->suspect_last_name : set_value('suspect_last_name') ?>
                <div class="form-group">
                    <label for="">Suspect Last Name</label>
                    <input type="text" name="suspect_last_name" id="suspect_last_name" class="form-control" value="<?=$suspect_last_name ?>" required>
                </div> 

                <div class="form-group">
                 <?php $case_type_id = isset($case) ? $case->case_type_id : set_value('case_type_id') ?>
                 <label for="">Select Case Type</label>
                 <select name="case_type_id" id="case_type_id" class="form-control" required>
                    <option value="">--select--</option>
                    <?php foreach(DB::get(TABLE_CASE_TYPES) as $row): ?>
                        <?php if($row->id == $case_type_id): ?>
                            <option value="<?=$row->id ?>" selected><?=$row->case_type ?></option>
                        <?php else: ?>
                            <option value="<?=$row->id ?>"><?=$row->case_type ?></option>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </select>
            </div> 

            
            <div class="form-group">
                <?php $date_of_report = isset($case) ? $case->date_of_report : date('Y-m-d') ?>
                <label for="">Date and time of Report <small class="text-info"><em>>>click the calendar icon below</em></small></label>
                <div class='input-group date' id='datetimepicker1'>
                    <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                    <input type='text' class="form-control"  name="date_of_report" value="<?=$date_of_report ?>" required>
                    
                </div>
            </div>

            <div class="form-group">
                <?php $crime_location = isset($case) ? $case->crime_location : set_value('crime_location') ?>
                <label for="">Crime Location</label>
                <textarea name="crime_location" id="crime_location" class="form-control" rows="3" required><?=$crime_location ?></textarea>
            </div> 

            <div class="form-group">
                <?php $description = isset($case) ? $case->description : set_value('description') ?>
                <label for="">Crime Description</label>
                <textarea name="description" id="description" class="form-control" rows="3" required><?=$description ?></textarea>
            </div> 

            <div class="form-group">
             <?php $status = isset($case) ? $case->status : set_value('status') ?>
             <label for="">Status</label>
             <select name="status" id="" class="form-control" required>
                 <option value="open" <?=$status == 'open' ? 'selected' : '' ?>>Open</option>
                 <option value="closed" <?=$status == 'closed' ? 'selected' : '' ?>>Closed</option>
             </select>
         </div>
         <?php if(isset($case)): ?>
            <input type="hidden" name="id" value="<?=$case->id ?>">
        <?php endif; ?>
        <button type="submit" class="btn btn-primary">Save</button>

        <?=form_close() ?>
    </div>
</div>


</div>

<?php $this->load->view('includes/footer') ?>

</div> 