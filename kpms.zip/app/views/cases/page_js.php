<script scr="<?=base_url('assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js') ?>"></script>
<script>
	function edit(id){
		var name = $('#name-'+id).html();
		var description = $('#description-'+id).html();

		$('#category_id').val(id);
		$('#name').val(name);
		$('#description').val(description);
		$('#modal').modal();
	}

	function edit_case_type(id){
		var case_type = $('#case_type-'+id).html();
		$('#case_type_id').val(id);
		$('#case_type').val(case_type);
		$('#modal').modal();
	}

	$(function () {
		$('#datetimepicker1').datetimepicker({
			showClear:true,
			showClose:true,

		});
	});
</script>