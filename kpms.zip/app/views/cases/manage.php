<div class="container">

    <!-- Page-Title -->
    <div class="row">
        <div class="col-sm-12">
            <div class="page-title-box">
                <div class="btn-group pull-right">
                    <ol class="breadcrumb hide-phone p-0 m-0">
                        <li>
                            <a href="#"><?=APP_NAME ?></a>
                        </li>
                        <li class="active">
                            Police Cases
                        </li>
                    </ol>
                </div>
                <h4 class="page-title">Police Cases</h4>
            </div>
        </div>
    </div>
    <!-- end page title end breadcrumb -->

    <?php $this->load->view('includes/alert') ?>
    <div class="row">
        <div class="col-sm-12">
            <div class="card-box table-responsive">
                <p class="text-muted font-13 m-b-30">
                    <a href="<?=site_url('cases/form') ?>" class="btn btn-inverse">Add New Case</a>
                </p>

                <table id="datatable-buttons" class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Case Number</th>
                            <th>Suspect Firstname</th>
                            <th>Suspect Lastname</th>
                            <th>Date of Report</th>
                            <th>Crime Location</th>
                            <th>Case Type</th>
                            <th>Status</th>
                            <th>Date Created</th>
                            <?php if(user_role() == ADMIN): ?>
                                <th>Actions</th>
                            <?php endif; ?>
                        </tr>
                    </thead>


                    <tbody>
                        <?php if(isset($cases)): ?>
                            <?php $count = 1; ?>
                            <?php foreach($cases as $row): ?>
                                <tr>
                                    <td><?=$row->case_number ?></td>
                                    <td id="suspect_first_name-<?=$row->id ?>">
                                        <?=$row->suspect_first_name ?>
                                    </td>
                                    <td id="suspect_last_name-<?=$row->id ?>">
                                        <?=$row->suspect_last_name ?>
                                    </td>
                                    <td id="date_of_report-<?=$row->id ?>"><?=$row->date_of_report ?></td>
                                    <td id="crime_location-<?=$row->id ?>"><?=ucwords($row->crime_location) ?></td>
                                    <td>
                                        <span id="case_type" style="display:none;"><?=$row->case_type_id ?></span>
                                        <?=$row->case_type ?>
                                    </td>
                                    <td id="status-<?=$row->id ?>"><?=$row->status ?></td>
                                    <td><?=$row->created_at ?></td>
                                    <?php if(user_role() == ADMIN): ?>
                                        <td>
                                            <div class="btn-group">
                                                <button type="button" class="btn btn-default dropdown-toggle waves-effect" data-toggle="dropdown" aria-expanded="true"> Dropdown <span class="caret"></span> </button>
                                                <ul class="dropdown-menu">
                                                    <li><a href="<?=site_url('cases/single/'.$row->id) ?>">Edit</a></li>
                                                    <li><a href="<?=site_url('cases/delete/'.$row->id)?>" onclick="return confirm('Are you sure?')">Delete</a></li>
                                                </ul>
                                            </div>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <?php $this->load->view('includes/footer') ?>

    </div> <!-- end container -->