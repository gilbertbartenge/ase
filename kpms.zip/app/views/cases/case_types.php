<div class="container">

            <!-- Page-Title -->
            <div class="row">
                <div class="col-sm-12">
                    <div class="page-title-box">
                        <div class="btn-group pull-right">
                            <ol class="breadcrumb hide-phone p-0 m-0">
                                <li>
                                    <a href="#"><?=APP_NAME ?></a>
                                </li>
                                <li class="active">
                                    Case Types
                                </li>
                            </ol>
                        </div>
                        <h4 class="page-title">Case Types</h4>
                    </div>
                </div>
            </div>
            <!-- end page title end breadcrumb -->

            <?php $this->load->view('includes/alert') ?>
            <div class="row">
                <div class="col-sm-12">
                    <div class="card-box table-responsive">
                        <p class="text-muted font-13 m-b-30">
                            <a data-toggle="modal" href='#modal' class="btn btn-inverse">Add Case Type</a>
                        </p>

                        <table id="datatable-buttons" class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>S/NO</th>
                                    <th>Case Type</th>
                                    <th>Date Created</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>


                            <tbody>
                            <?php if(isset($case_types)): ?>
                                <?php $count = 1; ?>
                                <?php foreach($case_types as $row): ?>
                                    <tr>
                                        <td><?=$count++ ?></td>
                                        <td id="case_type-<?=$row->id ?>"><?=ucfirst($row->case_type) ?></td>
                                        <td><?=$row->created_at ?></td>
                                        <td>
                                        <div class="btn-group">
                                                <button type="button" class="btn btn-default dropdown-toggle waves-effect" data-toggle="dropdown" aria-expanded="true"> Dropdown <span class="caret"></span> </button>
                                                <ul class="dropdown-menu">
                                                    <li><a href="javascript:void(0);" onclick="edit_case_type('<?=$row->id ?>')">Edit</a></li>
                                                    <li><a href="<?=site_url('cases/delete_case_type/'.$row->id)?>" onclick="return confirm('Are you sure?')">Delete</a></li>
                                                </ul>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="modal">
                <div class="modal-dialog">
                    <?=form_open('cases/manage_case_types') ?>
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            <h4 class="modal-title">Case Types</h4>
                        </div>
                        <div class="modal-body">
                         <div class="form-group">
                             <label for="">Case Type*</label>
                             <input type="text" name="case_type" class="form-control" id="case_type" required>
                         </div> 

                         <input type="hidden" name="id" id="case_type_id">
                     </div>
                     <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </div>
                <?=form_close() ?>
            </div>
        </div>

        <?php $this->load->view('includes/footer') ?>

    </div> <!-- end container -->