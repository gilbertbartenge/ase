<script>
	function edit(id){
		var name = $('#name-'+id).html();
		var description = $('#description-'+id).html();

		$('#category_id').val(id);
		$('#name').val(name);
		$('#description').val(description);
		$('#modal').modal();
	}

	function edit_formation(id){
		var name = $('#name-'+id).html();
		var police_category_id = $('#police_category_id-'+id).html();

		$('#formation_id').val(id);
		$('#name').val(name);
		$('#police_category_id').val(police_category_id);
		$('#modal').modal();
	}
</script>