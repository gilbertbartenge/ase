<div class="container">

    <!-- Page-Title -->
    <div class="row">
        <div class="col-sm-12">
            <div class="page-title-box">
                <div class="btn-group pull-right">
                    <ol class="breadcrumb hide-phone p-0 m-0">
                        <li>
                            <a href="#">App Name</a>
                        </li>
                        <li class="active">
                            Users
                        </li>
                    </ol>
                </div>
                <h4 class="page-title">Users</h4>
            </div>
        </div>
    </div>
    <!-- end page title end breadcrumb -->

    <?php $this->load->view('includes/alert') ?>
    <div class="row">
        <div class="col-sm-12">
            <div class="card-box table-responsive">
                <p class="text-muted font-13 m-b-30">
                    <a href="<?=site_url('users/manage') ?>" class="btn btn-inverse">Add New User</a>
                </p>

                <table id="datatable-buttons" class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>S/NO</th>
                            <th>Role</th>
                            <th>Full Name</th>
                            <th>Email Address</th>
                            <th>Police Category</th>
                            <th>Police Formation</th>
                            <th>Actions</th>
                        </tr>
                    </thead>


                    <tbody>
                        <?php if(isset($users)): ?>
                            <?php $count = 1; ?>
                            <?php foreach($users as $row):?>
                                <tr>
                                    <td><?=$count++ ?></td>
                                    <td><?=strtoupper($row->role) ?></td>
                                    <td><?=ucwords($row->first_name.' '.$row->last_name) ?></td>
                                    <td><a href="mailto:<?=$row->email?>?subject=feedback" "email me"><?=$row->email ?></a></td>
                                    <td><?=DB::get_cell(TABLE_POLICE_CATEGORIES, ['id'=>$row->police_category_id], 'name') ?></td>
                                    <td><?=DB::get_cell(TABLE_POLICE_FORMULATIONS, ['id'=>$row->police_formulation_id], 'name') ?></td>
                                    <td>
                                        <div class="btn-group">
                                            <button type="button" class="btn btn-danger dropdown-toggle waves-effect" data-toggle="dropdown" aria-expanded="true"> Dropdown <span class="caret"></span> </button>
                                            <ul class="dropdown-menu">
                                            <li><a href="<?=site_url('users/ban/'.$row->id) ?>" onclick="return confirm('Are you sure?')">Ban User</a></li>
                                                <li><a href="<?=site_url('users/delete/'.$row->id) ?>" onclick="return confirm('Are you sure?')">Delete User</a></li>
                                            </ul>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="modal fade" id="modal-id">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Police Category</h4>
                </div>
                <div class="modal-body">
                 <div class="form-group">
                     <label for="">Police Category Name</label>
                     <input type="text" name="name" class="form-control">
                 </div> 
             </div>
             <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save changes</button>
            </div>
        </div>
    </div>
</div>

<?php $this->load->view('includes/footer') ?>

    </div> <!-- end container -->