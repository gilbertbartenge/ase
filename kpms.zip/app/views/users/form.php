    <div class="container">
        <!-- Page-Title -->
        <?php $this->load->view('includes/alert') ?>
        <div class="row">
            <div class="col-sm-12">
                <div class="page-title-box">
                    <div class="btn-group pull-right">
                        <ol class="breadcrumb hide-phone p-0 m-0">
                            <li>
                                <a href="#"><?=APP_NAME ?></a>
                            </li>
                            <li class="active">
                                System Users
                            </li>
                        </ol>
                    </div>
                    <h4 class="page-title">System Users</h4>
                </div>
            </div>
        </div>
        <!-- end page title end breadcrumb -->

        <div class="row">
            <div class="col-sm-12">
                <div class="card-box table-responsive">
                    <h4 class="m-t-0 header-title"><b>System Users Form</b></h4>

                    <?=form_open('users/manage', ['class'=>'form-horizontal']) ?>
                    <div class="row">
                     <div class="col-md-6">
                         <div class="form-group">
                            <label class="col-md-2 control-label" for="member_surname">First Name</label>
                            <div class="col-md-10">
                                <input type="text" class="form-control" name="first_name" value="<?=set_value('first_name') ?>">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label class="col-md-2 control-label" for="member_surname">Last Name</label>
                        <div class="col-md-10">
                            <input type="text" class="form-control" name="last_name" value="<?=set_value('last_name') ?>">
                        </div>
                    </div> 
                </div>
            </div> 
            <div class="row">
             <div class="col-md-6">
              <div class="form-group">
                <label class="col-md-2 control-label" for="member_surname">Email</label>
                <div class="col-md-10">
                    <input type="email" class="form-control" name="email" value="<?=set_value('email') ?>">
                </div>
            </div> 
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label class="col-md-2 control-label" for="member_surname">Phone</label>
            <div class="col-md-10">
                <input type="text" class="form-control" name="phone" value="<?=set_value('phone') ?>">
            </div>
        </div> 
    </div>
</div> 

<div class="row">
    <div class="col-md-4">
        <div class="form-group">
            <label class="col-md-2 control-label" for="member_surname">User Role</label>
            <div class="col-md-10">
                <select name="role" id="role" class="form-control" id="role" required onchange="check_police()">
                    <option value="client">Client</option>
                    <option value="police">Police</option>
                    <option value="admin">Admin</option>
                </select>
            </div>
        </div>
    </div>
    <div class="police">
      <div class="col-md-4">
        <div class="form-group">
            <label class="col-md-2 control-label" for="member_surname">Police Category</label>
            <div class="col-md-10">
                <select name="police_category_id" id="police_category_id" class="form-control" onchange="fetch_dept()">
                    <option value="">--select--</option>
                    <?php foreach(DB::get(TABLE_POLICE_CATEGORIES) as $row): ?>
                        <option value="<?=$row->id ?>"><?=$row->name ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
    </div>

    <div class="col-md-4">
     <div class="form-group">
        <label class="col-md-2 control-label" for="member_surname">Formation</label>
        <div class="col-md-10">
            <select name="police_formulation_id" id="formulation_id" class="form-control">
            </select>
        </div>
    </div> 
</div>  
</div>

</div>


<div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <label class="col-md-2 control-label" for="member_surname">Password</label>
            <div class="col-md-10">
                <input type="password" class="form-control" name="password" requierd>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
            <label class="col-md-2 control-label" for="member_surname">Retype Password</label>
            <div class="col-md-10">
                <input type="password" class="form-control" name="retype_password" requierd> 
            </div>
        </div>
    </div>
</div>



<div class="form-group">
 <div class="col-offset-md-2 col-md-6">
   <button class="btn btn-purple waves-effect waves-light m-b-5" type="submit"> 
    <i class="mdi mdi-checkbox-multiple-marked-circle-outline"></i> 
    <span>Submit</span> 
</button> 
</div>
</div>

<?=form_close() ?>
</div>
</div>


</div>

<?php $this->load->view('includes/footer') ?>

</div> 