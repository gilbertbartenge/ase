<script>
	$('.police').hide();
	function fetch_dept()
	{
		var police_category_id = $('#police_category_id').val();
		url = "<?=site_url('categories/fetch_formation/') ?>"+police_category_id
		$.get(url, function(response){
			$('#formulation_id').html(response);
		})
	}

	function check_police()
	{
		var role = $('#role').val();
		if(role == 'client'){
			$('.police').hide();
		}else{
			$('.police').show();
		}
	}
</script>