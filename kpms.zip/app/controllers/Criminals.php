<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Criminals extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		if(!Auth::is_loggedin())
			Auth::Bounce($this->uri->uri_string());
	}

	public function index()
	{
		$data['title'] = 'criminals';
		$data['page'] = 'criminals/manage';
		$data['page_js'] = 'criminals/page_js';
		$data['criminals'] = DB::get(TABLE_CRIMINALS, 'first_name', 'ASC');
		$this->load->view('table_template', $data);
	}

	public function manage()
	{
		if (!$this->input->post())
			redirect('criminals');

		$data = $this->input->post();
		if ($this->input->post('id')) {
			$this->form_validation->set_rules('first_name', 'Criminal First Name', 'required|alpha');
			$this->form_validation->set_rules('last_name', 'Criminal Last Name', 'required|alpha');
			if($this->form_validation->run() == FALSE) {
				redirect('criminals');
			}

			$id = $this->input->post('id');
			unset($data['id']);
			$where = ['id'=>$id];
			if(DB::update(TABLE_CRIMINALS, $where, $data)) {
				$this->session->set_flashdata(SUCCESS, ACTION_SUCCESFUL);
			} else {
				$this->session->set_flashdata(ERROR, ACTION_UNSUCCESFUL);
			}
			$this->index();
		} else {
			$this->form_validation->set_rules('first_name', 'Criminal First Name', 'required|alpha');
			$this->form_validation->set_rules('last_name', 'Criminal Last Name', 'required|alpha');
			if ($this->form_validation->run() == FALSE) {
				$this->index();
			} else {
				$data = $this->input->post();
				$data['created_at'] = date('Y-m-d H:i:s');
				if ($insert_id = DB::save(TABLE_CRIMINALS, $data)) {
					$this->session->set_flashdata(SUCCESS, ACTION_SUCCESFUL);
				} else {
					$this->session->set_flashdata(ERROR, ACTION_UNSUCCESFUL);
				}
				$this->index();
			}

		}
	}

	public function upload_image()
	{
		if(!$this->input->post())
			redirect('criminals');
		$config['upload_path']			= 'assets/criminals/';
		$config['allowed_types']		= 'gif|jpg|png|PNG|JPG';
		$config['max_size']				= '300';
		$config['file_name'] 			= md5($this->input->post('criminal_id'));
		$config['overwrite']			= true;
		$this->load->library('upload', $config);
		if(!$this->upload->do_upload('image')) {
			$this->session->set_flashdata(ERROR, $this->upload->display_errors());
			$this->index();
		} else {
			$file_name = $this->upload->data('file_name');
			$where = ['id'=>$this->input->post('criminal_id')];
			$data = ['image'=> $file_name];
			if(DB::update(TABLE_CRIMINALS, $where, $data)) {
				$this->session->set_flashdata(SUCCESS, ACTION_SUCCESFUL);
				$this->index();
			} else {
				$this->session->set_flashdata(ERROR, ACTION_UNSUCCESFUL);
			}
		}
	}

	public function delete($id = 0)
	{
		if(DB::delete(TABLE_CRIMINALS, ['id'=>$id])){
			$this->session->set_flashdata(SUCCESS, ACTION_SUCCESFUL);
		}else{
			$this->session->set_flashdata(ERROR, ACTION_UNSUCCESFUL);
		}
		$this->index();
	}


}
