<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cases extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		if(!Auth::is_loggedin())
				Auth::Bounce($this->uri->uri_string());
	}

	public function index()
	{
		$data['title'] = 'cases';
		$data['page'] = 'cases/manage';
		$data['page_js'] = 'cases/page_js';

		$query = $this->db->join(TABLE_CASE_TYPES, TABLE_CASE_TYPES.'.id = '.TABLE_POLICE_CASES.'.case_type_id');
		$query = $this->db->order_by('case_number', 'DESC');
		$query = $this->db->get(TABLE_POLICE_CASES);
		$data['cases'] = $query->result();

		$this->load->view('table_template', $data);
	}

	public function form()
	{
		$data['title'] = 'Cases';
		$data['page'] = 'cases/form';
		$data['page_js'] = 'cases/page_js';
		$this->load->view('table_template', $data);
	}

	public function manage()
	{
		if (!$this->input->post())
			redirect('cases');

		$data = $this->input->post();
		if ($this->input->post('id')) {
			$this->form_validation->set_rules('suspect_first_name', 'Suspect First Name', 'required|alpha_numeric_spaces');
			$this->form_validation->set_rules('suspect_last_name', 'Suspect Last Name', 'required|alpha_numeric_spaces');
			$this->form_validation->set_rules('case_type_id', 'Case Type', 'required');
			$this->form_validation->set_rules('date_of_report', 'Date of Report', 'required');
			$this->form_validation->set_rules('crime_location', 'Crime Location', 'required');
			$this->form_validation->set_rules('description', 'Crime Description', 'required');
			$this->form_validation->set_rules('status', 'Status', 'required');
			if($this->form_validation->run() == FALSE) {
					redirect('cases/single/'.$data['id']);
				}

			$id = $this->input->post('id');
			unset($data['id']);
			$where = ['id'=>$id];
			$data['date_of_report'] = date('Y-m-j H:i:s', strtotime($data['date_of_report']));
			if(DB::update(TABLE_POLICE_CASES, $where, $data)) {
				$this->session->set_flashdata(SUCCESS, ACTION_SUCCESFUL);
			} else {
				$this->session->set_flashdata(ERROR, ACTION_UNSUCCESFUL);
			}
			$this->index();
		} else {
			$this->form_validation->set_rules('suspect_first_name', 'Suspect First Name', 'required|alpha_numeric_spaces');
			$this->form_validation->set_rules('suspect_last_name', 'Suspect Last Name', 'required|alpha_numeric_spaces');
			$this->form_validation->set_rules('case_type_id', 'Case Type', 'required');
			$this->form_validation->set_rules('date_of_report', 'Date of Report', 'required');
			$this->form_validation->set_rules('crime_location', 'Crime Location', 'required');
			$this->form_validation->set_rules('description', 'Crime Description', 'required');
			$this->form_validation->set_rules('status', 'Status', 'required');
			if ($this->form_validation->run() == FALSE) {
				$this->form();
			} else {
				$data = $this->input->post();
				$data['created_at'] = date('Y-m-d H:i:s');
				$data['user_id'] = $this->session->userdata('user_id');
				$data['date_of_report'] = date('Y-m-j H:i:s', strtotime($data['date_of_report']));
				$this->load->helper('string');
				$data['case_number'] = random_string('numeric', 6);
				if ($insert_id = DB::save(TABLE_POLICE_CASES, $data)) {
					$this->session->set_flashdata(SUCCESS, ACTION_SUCCESFUL);
				} else {
					$this->session->set_flashdata(ERROR, _l('action_unsuccesful'));
				}
				$this->index();
			}

		}
	}

	public function single($case_id = 0)
	{
		$data['title'] = 'Cases';
		$data['page'] = 'cases/form';
		$data['page_js'] = 'cases/page_js';
		$data['case'] = DB::get_row(TABLE_POLICE_CASES, ['id'=>$case_id]);
		$this->load->view('table_template', $data);
	}

	public function case_types()
	{
		$data['title'] 		= 'cases types';
		$data['page'] 		= 'cases/case_types';
		$data['page_js'] 	= 'cases/page_js';
		$data['case_types'] = DB::get(TABLE_CASE_TYPES, 'case_type', 'ASC');
		$this->load->view('table_template', $data);
	}

	public function manage_case_types()
	{
		if (!$this->input->post())
			redirect('cases/case_types');

		$data = $this->input->post();
		if ($this->input->post('id')) {
			$this->form_validation->set_rules('case_type', 'Case Type', 'required');
			if($this->form_validation->run() == FALSE) {
					$this->session->set_flashdata(ERROR, ACTION_UNSUCCESFUL);
					redirect('cases/case_types');
					redirect('cases/case_types')
				}

			$id = $this->input->post('id');
			unset($data['id']);
			$where = ['id'=>$id];
			if(DB::update(TABLE_CASE_TYPES, $where, $data)) {
				$this->session->set_flashdata(SUCCESS, ACTION_SUCCESFUL);
			} else {
				$this->session->set_flashdata(ERROR, ACTION_UNSUCCESFUL);
			}
			$this->case_types();
		} else {
			$this->form_validation->set_rules('case_type', 'Case Type', 'required');
			if ($this->form_validation->run() == FALSE) {
				$this->case_types();
			} else {
				$data = $this->input->post();
				$data['created_at'] = date('Y-m-d H:i:s');
				if ($insert_id = DB::save(TABLE_CASE_TYPES, $data)) {
					$this->session->set_flashdata(SUCCESS, ACTION_SUCCESFUL);
				} else {
					$this->session->set_flashdata(ERROR, ACTION_UNSUCCESFUL);
				}
				$this->case_types();
			}

		}
	}

	public function delete($id = 0)
	{
		if(DB::delete(TABLE_POLICE_CASES, ['id'=>$id])){
			$this->session->set_flashdata(SUCCESS, ACTION_SUCCESFUL);
		}else{
			$this->session->set_flashdata(ERROR, ACTION_UNSUCCESFUL);
		}
		$this->index();
	}

	public function delete_case_type($id = 0)
	{
		if(DB::num_rows(TABLE_POLICE_CASES, ['case_type_id'=>$id]) > 0){
			$this->session->set_flashdata(ERROR, 'Case type cannot be deleted. it is currently used in some cases.');
		}elseif(DB::delete(TABLE_CASE_TYPES, ['id'=>$id])){
			$this->session->set_flashdata(SUCCESS, ACTION_SUCCESFUL);
		}else{
			$this->session->set_flashdata(ERROR, ACTION_UNSUCCESFUL);
		}
		$this->case_types();
	}


}
