<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		if(!Auth::is_loggedin())
			Auth::Bounce($this->uri->uri_string());
	}

	public function index()
	{
		$data['title'] = 'Users';
		$data['page'] = 'users/manage';
		$data['page_js'] = 'users/page_js';
		$data['users'] = DB::get(TABLE_USERS, 'first_name', 'ASC');
		$this->load->view('table_template', $data);
	}

	public function form()
	{
		$data['title'] = 'Users';
		$data['page'] = 'users/form';
		$data['page_js'] = 'users/page_js';
		$this->load->view('table_template', $data);
	}

	public function manage()
	{
		if (!$this->input->post())
			redirect('users/form');
		$data = $this->input->post();
		if ($this->input->post('id')) {
			
			$this->form_validation->set_rules('email', 'User Email', 'required|alpha|is_unique['.TABLE_USERS.'.email]');
			$this->form_validation->set_rules('first_name', 'First Name', 'required|alpha');
			$this->form_validation->set_rules('last_name', 'Last Name', 'required|alpha');
			$this->form_validation->set_rules('role', 'Role', 'required');
			$this->form_validation->set_rules('phone', 'Phone', 'required');
			if($this->form_validation->run() == FALSE) {
				$this->session->set_flashdata(ERROR, _l('action_unsuccessful'));
				$this->form();
			}

			$id = $this->input->post('id');
			unset($data['id']);
			$where = ['id'=>$id];
			if(DB::update(TABLE_USERS, $where, $data)) {
				$this->session->set_flashdata(SUCCESS, _l('action_successful'));
			} else {
				$this->session->set_flashdata(ERROR, _l('action_unsuccessful'));
			}
			$this->form();
		} else {
			$this->form_validation->set_rules('email', 'User Email', 'required|valid_email|is_unique['.TABLE_USERS.'.email]');
			$this->form_validation->set_rules('first_name', 'First Name', 'required|alpha');
			$this->form_validation->set_rules('last_name', 'Last Name', 'required|alpha');
			$this->form_validation->set_rules('role', 'Role', 'required');
			$this->form_validation->set_rules('phone', 'Phone', 'required');
			$this->form_validation->set_rules('password', 'Password', 'required|matches[retype_password]');
			$this->form_validation->set_rules('retype_password', 'Retype Password', 'required');
			if ($this->form_validation->run() == FALSE) {
				$this->form();
			} else {
				$data = $this->input->post();
				$data['created_at'] = date('Y-m-d H:i:s');
				unset($data['retype_password']);
				$data['password'] = hash('sha256', $data['password']);
				if ($insert_id = DB::save(TABLE_USERS, $data)) {
					$this->session->set_flashdata(SUCCESS, ACTION_SUCCESFUL);
				} else {
					$this->session->set_flashdata(ERROR, ACTION_UNSUCCESFUL);
				}
				$this->index();
			}

		}
	}


	public function delete($id = 0)
	{
		if(DB::num_rows(TABLE_POLICE_CASES, ['user_id'=>$id]) > 0){
			$this->session->set_flashdata(ERROR, 'User cannot be deleted. user has data in the police cases records');
		}elseif(DB::delete(TABLE_CASE_TYPES, ['id'=>$id])){
			$this->session->set_flashdata(SUCCESS, ACTION_SUCCESFUL);
		}else{
			$this->session->set_flashdata(ERROR, ACTION_UNSUCCESFUL);
		}
		$this->index();
	}

	public function ban($id = 0)
	{
		if(DB::update(TABLE_CASE_TYPES, ['id'=>$id], ['banned'=>1])){
			$this->session->set_flashdata(SUCCESS, ACTION_SUCCESFUL);
		}else{
			$this->session->set_flashdata(ERROR, ACTION_UNSUCCESFUL);
		}
		$this->index();
	}


}
