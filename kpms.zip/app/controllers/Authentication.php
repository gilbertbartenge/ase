<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Authentication extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
	}


	

	public function index()
	{

		if(Auth::is_loggedin()){
			redirect(site_url('home'));
		}
		if ($this->input->post()) {
			$this->form_validation->set_rules('email', 'Email', 'required|valid_email');
			$this->form_validation->set_rules('password', 'Password', 'required');
			if ($this->form_validation->run() == FALSE){
				$this->load->view('auth/login');
			}else {
				$data = [
				'email'=>$this->input->post('email'),
				'password'=> hash('sha256', $this->input->post('password'))
				];

				if(Auth::login($data)) {
					if($this->session->userdata('previous_url')) {
						redirect(site_url($this->session->userdata('previous_url')));
					} else {
						redirect(site_url('home'));
					}
				} else {
					$this->session->set_flashdata(ERROR, '<p class="error">Invalid Email/Password</p>');
				}
			}
		}
		$this->load->view('auth/login');
	}

	public function logout()
	{
		Auth::logout();
	}

	public function create_user()
	{
		$data = [
		'username'=>'ivans', 
		'email'=>'evanschumba@gmail.com',
		'role'=>9,
		'created_at'=>date('Y-m-d h:i:s'),
		'password'=>hash('sha256', 'password')
		];
		DB::save(TABLE_USERS, $data);
	}

	public function landing()
	{
		if(Auth::is_loggedin()){
			redirect(site_url('home'));
		}
		
		$this->load->view('landing-page');
	}

}
