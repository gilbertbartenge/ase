<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Stations extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		if(!Auth::is_loggedin())
				Auth::Bounce($this->uri->uri_string());
	}

	public function index()
	{
		$data['title'] = 'stations';
		$data['page'] = 'stations/manage';
		$data['page_js'] = 'stations/page_js';
		$data['stations'] = DB::get(TABLE_POLICE_STATIONS, 'name', 'ASC');
		$this->load->view('table_template', $data);
	}

	public function manage()
	{
		if (!$this->input->post())
			redirect('stations');

		$data = $this->input->post();
		if ($this->input->post('id')) {
			
			$this->form_validation->set_rules('name', 'Police Station Name', 'required');
			$this->form_validation->set_rules('county_id', 'County', 'required');
			$this->form_validation->set_rules('address', 'Address', 'required');
			$this->form_validation->set_rules('phone', 'Phone', 'required');
			$this->form_validation->set_rules('police_category_id', 'Police Category ID', 'required');
			if($this->form_validation->run() == FALSE) {
					$this->session->set_flashdata(ERROR, ACTION_UNSUCCESFUL);
					redirect('stations');
				}

			$id = $this->input->post('id');
			unset($data['id']);
			$where = ['id'=>$id];
			if(DB::update(TABLE_POLICE_STATIONS, $where, $data)) {
				$this->session->set_flashdata(SUCCESS, ACTION_SUCCESFUL);
			} else {
				$this->session->set_flashdata(ERROR, ACTION_UNSUCCESFUL);
			}
			$this->index();
		} else {
			$this->form_validation->set_rules('name', 'Police Category Name', 'required|alpha_numeric_spaces|is_unique['.TABLE_POLICE_STATIONS.'.name]');
			$this->form_validation->set_rules('county_id', 'County', 'required');
			$this->form_validation->set_rules('address', 'Address', 'required');
			$this->form_validation->set_rules('phone', 'Phone', 'required');
			$this->form_validation->set_rules('police_category_id', 'Police Category ID', 'required');
			if ($this->form_validation->run() == FALSE) {
				$this->index();
			} else {
				$data = $this->input->post();
				$data['created_at'] = date('Y-m-d H:i:s');
				if ($insert_id = DB::save(TABLE_POLICE_STATIONS, $data)) {
					$this->session->set_flashdata(SUCCESS, ACTION_SUCCESFUL);
				} else {
					$this->session->set_flashdata(ERROR, _l('action_unsuccesful'));
				}
				$this->index();
			}

		}
	}


	public function delete($id = 0)
	{
		if(DB::delete(TABLE_POLICE_STATIONS, ['id'=>$id])){
			$this->session->set_flashdata(SUCCESS, ACTION_SUCCESFUL);
		}else{
			$this->session->set_flashdata(ERROR, ACTION_UNSUCCESFUL);
		}
		$this->index();
	}


}
