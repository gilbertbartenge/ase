<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Categories extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		if(!Auth::is_loggedin())
				Auth::Bounce($this->uri->uri_string());
	}

	public function index()
	{
		$data['title'] = 'categories';
		$data['page'] = 'categories/manage';
		$data['page_js'] = 'categories/page_js';
		$data['categories'] = DB::get(TABLE_POLICE_CATEGORIES, 'name', 'ASC');
		$this->load->view('table_template', $data);
	}

	public function manage()
	{
		if (!$this->input->post())
			redirect('categories');

		$data = $this->input->post();
		if ($this->input->post('id')) {
			if ($data['name'] != DB::get_cell(TABLE_POLICE_CATEGORIES, array('id'=>$data['id']), 'name')) {
				$this->form_validation->set_rules('name', 'Police Category Name', 'required|alpha_numeric_spaces|is_unique['.TABLE_POLICE_CATEGORIES.'.name]');
				if($this->form_validation->run() == FALSE) {
					$this->session->set_flashdata(ERROR, ACTION_SUCCESFUL);
					redirect('categories');
				}
			}

			$id = $this->input->post('id');
			unset($data['id']);
			$where = ['id'=>$id];
			if(DB::update(TABLE_POLICE_CATEGORIES, $where, $data)) {
				$this->session->set_flashdata(SUCCESS, ACTION_SUCCESFUL);
			} else {
				$this->session->set_flashdata(ERROR, ACTION_UNSUCCESFUL);
			}
			$this->index();
		} else {
			$this->form_validation->set_rules('name', 'Police Category Name', 'required|alpha_numeric_spaces|is_unique['.TABLE_POLICE_CATEGORIES.'.name]');
			if ($this->form_validation->run() == FALSE) {
				$this->index();
			} else {
				$data = $this->input->post();
				$data['created_at'] = date('Y-m-d H:i:s');
				if ($insert_id = DB::save(TABLE_POLICE_CATEGORIES, $data)) {
					$this->session->set_flashdata(SUCCESS, ACTION_SUCCESFUL);
				} else {
					$this->session->set_flashdata(ERROR, _l('action_unsuccesful'));
				}
				$this->index();
			}

		}
	}

	public function formulations()
	{
		$data['title'] 	= 'formulations';
		$data['page'] = 'categories/formulations';
		$data['page_js'] = 'categories/page_js';
		$data['formulations'] = DB::get(TABLE_POLICE_FORMULATIONS, 'name', 'ASC');
		$this->load->view('table_template', $data);
	}

	public function manage_formulations()
	{
		if (!$this->input->post())
			redirect('categories/formulations');

		$data = $this->input->post();
		if ($this->input->post('id')) {
			if ($data['name'] != DB::get_cell(TABLE_POLICE_FORMULATIONS, array('id'=>$data['id']), 'name')) {
				$this->form_validation->set_rules('name', 'Police Formulation Name', 'required|alpha_numeric_spaces|is_unique['.TABLE_POLICE_FORMULATIONS.'.name]');
				
			}

			$this->form_validation->set_rules('police_category_id', 'Police Category', 'required');
			if($this->form_validation->run() == FALSE) {
				$this->session->set_flashdata(ERROR, ACTION_UNSUCCESFUL);
				redirect('categories/formulations');
			}

			$id = $this->input->post('id');
			unset($data['id']);
			$where = ['id'=>$id];
			if(DB::update(TABLE_POLICE_FORMULATIONS, $where, $data)) {
				$this->session->set_flashdata(SUCCESS, ACTION_SUCCESFUL);
			} else {
				$this->session->set_flashdata(ERROR, ACTION_UNSUCCESFUL);
			}
			$this->formulations();
		} else {
			$this->form_validation->set_rules('name', 'Police Formulation Name', 'required|alpha_numeric_spaces|is_unique['.TABLE_POLICE_CATEGORIES.'.name]');
			$this->form_validation->set_rules('police_category_id', 'Police Category', 'required');
			if ($this->form_validation->run() == FALSE) {
				$this->index();
			} else {
				$data = $this->input->post();
				$data['created_at'] = date('Y-m-d H:i:s');
				if ($insert_id = DB::save(TABLE_POLICE_FORMULATIONS, $data)) {
					$this->session->set_flashdata(SUCCESS, ACTION_SUCCESFUL);
				} else {
					$this->session->set_flashdata(ERROR, _l('action_unsuccesful'));
				}
				$this->formulations();
			}

		}
	}


	public function delete($id = 0)
	{
		if(DB::num_rows(TABLE_POLICE_FORMULATIONS, ['id'=>$id]) > 0){
			$this->session->set_flashdata(ERROR, 'Category cannot be deleted. it is currently used in some formulations.');
		}elseif(DB::delete(TABLE_POLICE_CATEGORIES, ['id'=>$id])){
			$this->session->set_flashdata(SUCCESS, ACTION_SUCCESFUL);
		}else{
			$this->session->set_flashdata(ERROR, ACTION_UNSUCCESFUL);
		}
		$this->index();
	}

	public function delete_formulation($id = 0)
	{
		if(DB::delete(TABLE_POLICE_FORMULATIONS, ['id'=>$id])){
			$this->session->set_flashdata(SUCCESS, ACTION_SUCCESFUL);
		}else{
			$this->session->set_flashdata(ERROR, ACTION_UNSUCCESFUL);
		}
		$this->formulations();
	}

	public function delete_formaiton($id = 0)
	{
		redirect('categories/formations');
		// $where = array('id'=>$id);
		// if(has_subcategories($id)) {
		// 	$this->session->set_flashdata(ERROR, 'Category has Subcategories. Action Unsuccesful');
		// 	redirect('backend/catgories');
		// }
		// if (delete(TABLE_POLICE_CATEGORIES, $where)) {
		// 	logActivity('Category Deleted. [ID:'.$id.']');
		// 	$this->session->set_flashdata(SUCCESS, 'Action Succesful.');
		// } else {
		// 	$this->session->set_flashdata(ERROR, 'Action Unsuccesful.');
		// }
		// $this->index();
	}


	public function fetch_formation($police_category_id = 0)
	{
		$options = '';
		$formation = DB::get(TABLE_POLICE_FORMULATIONS, '', '', '', '', ['police_category_id'=>$police_category_id]);
		foreach($formation as $row){
			$options.="<option value='{$row->id}'>{$row->name}</option>";
		}
		echo $options;
	}

}
